package com.example.utilclient;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public class Payloads {
    /** client -> server: action 0 bay (0/1), 1 toc do bay, 2 toc do chay, 3 toc do dao, 4 dao 3x3 (0/1) */
    public record Setting(int action, double value) implements CustomPayload {
        public static final Id<Setting> ID = new Id<>(Identifier.of(UtilMod.ID, "setting"));
        public static final PacketCodec<RegistryByteBuf, Setting> CODEC = PacketCodec.tuple(
                PacketCodecs.INTEGER, Setting::action, PacketCodecs.DOUBLE, Setting::value, Setting::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** server -> client: trang thai hien tai de ve menu / HUD */
    public record Sync(boolean allowed, boolean fly, double flySpeed, double speed, double mine, boolean m3,
                       double maxFly, double maxSpeed, double maxMine) implements CustomPayload {
        public static final Id<Sync> ID = new Id<>(Identifier.of(UtilMod.ID, "sync"));
        public static final PacketCodec<RegistryByteBuf, Sync> CODEC = PacketCodec.of(
                (v, buf) -> {
                    buf.writeBoolean(v.allowed()); buf.writeBoolean(v.fly()); buf.writeDouble(v.flySpeed());
                    buf.writeDouble(v.speed()); buf.writeDouble(v.mine()); buf.writeBoolean(v.m3());
                    buf.writeDouble(v.maxFly()); buf.writeDouble(v.maxSpeed()); buf.writeDouble(v.maxMine());
                },
                buf -> new Sync(buf.readBoolean(), buf.readBoolean(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                        buf.readBoolean(), buf.readDouble(), buf.readDouble(), buf.readDouble()));
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }
}
