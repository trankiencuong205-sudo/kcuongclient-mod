# Util Client (Fabric 1.21.1)
Bay, chinh toc do chay/bay, dao nhanh (Speed Mine), dao 3x3.

## Cach hoat dong
Mod cai tren **server cua ban** va tren client. Moi thu chay phia server nen khong bi kick "flying" hay giat lui.
Mac dinh chi **OP** (hoac singleplayer) dung duoc. Doi trong `config/utilclient.properties`:
`opOnly=false` (cho moi nguoi), `maxFlySpeed`, `maxRunSpeed`, `maxMineSpeed`.

## Phim
- K: menu (bat/tat bay, chinh toc do bay / chay / dao, dao 3x3)
- G: bat/tat bay (bam cach 2 lan de bay nhu creative)
- V: bat/tat dao 3x3 (giu Shift = dao 1 o)

Dao 3x3 pha 9 o vuong goc huong ban nhin (nhin xuong/len thi mat phang ngang), roi do va hao mon cong cu nhu binh thuong.
Cai dat cho cong cu sai (vd dung tay khong pha da) thi o do se bi bo qua.

## Build
Day len GitHub, workflow `.github/workflows/build.yml` se build. Jar o muc Artifacts. Chua duoc build/thu thuc te.
Neu build bao khong tim thay `fabric-api:0.115.0+1.21.1` thi vao gradle.properties doi sang ban Fabric API 1.21.1 moi hon.
