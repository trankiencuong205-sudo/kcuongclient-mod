package com.example.utilclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class UtilClient implements ClientModInitializer {
    /** trang thai moi nhat server gui ve */
    static Payloads.Sync st = new Payloads.Sync(false, false, 3, 1, 1, false, 10, 5, 20);
    private static KeyBinding menu, fly, m3;

    static void send(int action, double v) { ClientPlayNetworking.send(new Payloads.Setting(action, v)); }

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Sync.ID, (payload, context) -> st = payload);
        menu = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.utilclient.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.utilclient"));
        fly = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.utilclient.fly", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.utilclient"));
        m3 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.utilclient.m3", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.utilclient"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null) return;
            while (menu.wasPressed()) mc.setScreen(new UtilScreen());
            while (fly.wasPressed()) send(0, st.fly() ? 0 : 1);
            while (m3.wasPressed()) send(4, st.m3() ? 0 : 1);
        });

        HudRenderCallback.EVENT.register((ctx, tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;
            int y = 4;
            if (!st.allowed()) return;
            String[] lines = {
                    st.fly() ? "Bay: BAT x" + fmt(st.flySpeed()) : null,
                    st.speed() > 1.001 ? "Chay: x" + fmt(st.speed()) : null,
                    st.mine() > 1.001 ? "Dao: x" + fmt(st.mine()) : null,
                    st.m3() ? "Dao 3x3: BAT" : null };
            for (String l : lines) if (l != null) { ctx.drawTextWithShadow(mc.textRenderer, Text.literal(l), 4, y, 0xFF9AE6A0); y += 10; }
        });
    }

    static String fmt(double d) { return d == Math.floor(d) ? String.valueOf((int) d) : String.format("%.1f", d); }
}
