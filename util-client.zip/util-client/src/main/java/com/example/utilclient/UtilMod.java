package com.example.utilclient;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Bay / chay nhanh / dao nhanh / dao 3x3. TAT CA chay phia server (cai mod len server cua ban) nen khong bi
 * kick "flying" hay giat lui. Chi OP (hoac singleplayer) moi dung duoc, doi trong config/utilclient.properties.
 */
public class UtilMod implements ModInitializer {
    public static final String ID = "utilclient";
    private static final Identifier SPEED_MOD = Identifier.of(ID, "speed");
    private static final Identifier MINE_MOD = Identifier.of(ID, "mine");

    // config
    static boolean opOnly = true;
    static double maxFly = 10, maxSpeed = 5, maxMine = 20;

    static class State { boolean fly, m3; double flySpeed = 3, speed = 1, mine = 1; boolean flyApplied; }
    static final Map<UUID, State> STATES = new ConcurrentHashMap<>();
    private static boolean busy = false;

    static State st(ServerPlayerEntity p) { return STATES.computeIfAbsent(p.getUuid(), k -> new State()); }

    static boolean allowed(ServerPlayerEntity p) {
        if (!opOnly) return true;
        return p.hasPermissionLevel(2) || p.getServer().isSingleplayer();
    }

    @Override
    public void onInitialize() {
        loadConfig();
        PayloadTypeRegistry.playC2S().register(Payloads.Setting.ID, Payloads.Setting.CODEC);
        PayloadTypeRegistry.playS2C().register(Payloads.Sync.ID, Payloads.Sync.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(Payloads.Setting.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            if (!allowed(p)) { sync(p); return; }
            State s = st(p);
            double v = payload.value();
            switch (payload.action()) {
                case 0 -> s.fly = v > 0.5;
                case 1 -> s.flySpeed = clamp(v, 1, maxFly);
                case 2 -> s.speed = clamp(v, 1, maxSpeed);
                case 3 -> s.mine = clamp(v, 1, maxMine);
                case 4 -> s.m3 = v > 0.5;
                default -> { }
            }
            apply(p);
            sync(p);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> { apply(handler.player); sync(handler.player); });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> STATES.remove(handler.player.getUuid()));
        ServerPlayerEvents.AFTER_RESPAWN.register((old, p, alive) -> { st(p).flyApplied = false; apply(p); });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                State s = STATES.get(p.getUuid());
                if (s != null && s.fly) applyFly(p, s);      // doi game mode co the reset abilities
            }
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (busy || !(world instanceof ServerWorld sw) || !(player instanceof ServerPlayerEntity sp)) return;
            State s = STATES.get(sp.getUuid());
            if (s == null || !s.m3 || !allowed(sp) || sp.isSneaking()) return;   // giu Shift = dao 1 o
            mine3x3(sw, sp, pos, state);
        });
    }

    private static void mine3x3(ServerWorld w, ServerPlayerEntity p, BlockPos c, BlockState center) {
        float pitch = p.getPitch();
        Direction f = p.getHorizontalFacing();
        busy = true;
        try {
            for (int a = -1; a <= 1; a++) {
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) continue;
                    BlockPos q;
                    if (Math.abs(pitch) > 55) q = c.add(a, 0, b);
                    else if (f.getAxis() == Direction.Axis.X) q = c.add(0, a, b);
                    else q = c.add(a, b, 0);
                    BlockState bs = w.getBlockState(q);
                    if (bs.isAir() || !bs.getFluidState().isEmpty()) continue;
                    if (bs.getHardness(w, q) < 0) continue;                       // bedrock...
                    if (bs.isToolRequired() && !p.canHarvest(bs)) continue;        // khong dung cong cu -> bo qua
                    if (!p.isCreative() && p.getMainHandStack().isEmpty() == false && p.getMainHandStack().getDamage() >= p.getMainHandStack().getMaxDamage() - 1 && p.getMainHandStack().isDamageable()) return; // sap hong cong cu
                    p.interactionManager.tryBreakBlock(q);
                }
            }
        } finally { busy = false; }
    }

    static void apply(ServerPlayerEntity p) {
        State s = st(p);
        boolean ok = allowed(p);
        EntityAttributeInstance sp = p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        if (sp != null) {
            sp.removeModifier(SPEED_MOD);
            if (ok && s.speed > 1.001) sp.addTemporaryModifier(new EntityAttributeModifier(SPEED_MOD, s.speed - 1, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        EntityAttributeInstance mn = p.getAttributeInstance(EntityAttributes.PLAYER_BLOCK_BREAK_SPEED);
        if (mn != null) {
            mn.removeModifier(MINE_MOD);
            if (ok && s.mine > 1.001) mn.addTemporaryModifier(new EntityAttributeModifier(MINE_MOD, s.mine - 1, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
        if (!ok) { s.fly = false; s.m3 = false; }
        applyFly(p, s);
    }

    static void applyFly(ServerPlayerEntity p, State s) {
        var ab = p.getAbilities();
        boolean changed = false;
        if (s.fly) {
            float spd = 0.05f * (float) s.flySpeed;
            if (!ab.allowFlying) { ab.allowFlying = true; changed = true; }
            if (Math.abs(ab.getFlySpeed() - spd) > 1e-4) { ab.setFlySpeed(spd); changed = true; }
            s.flyApplied = true;
        } else if (s.flyApplied) {
            s.flyApplied = false;
            if (!p.isCreative() && !p.isSpectator()) { ab.allowFlying = false; ab.flying = false; }
            ab.setFlySpeed(0.05f);
            changed = true;
        }
        if (changed) p.sendAbilitiesUpdate();
    }

    static void sync(ServerPlayerEntity p) {
        State s = st(p);
        ServerPlayNetworking.send(p, new Payloads.Sync(allowed(p), s.fly, s.flySpeed, s.speed, s.mine, s.m3, maxFly, maxSpeed, maxMine));
    }

    static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    private static void loadConfig() {
        Path f = FabricLoader.getInstance().getConfigDir().resolve("utilclient.properties");
        Properties pr = new Properties();
        try {
            if (Files.exists(f)) try (InputStream in = Files.newInputStream(f)) { pr.load(in); }
            opOnly = Boolean.parseBoolean(pr.getProperty("opOnly", "true"));
            maxFly = Double.parseDouble(pr.getProperty("maxFlySpeed", "10"));
            maxSpeed = Double.parseDouble(pr.getProperty("maxRunSpeed", "5"));
            maxMine = Double.parseDouble(pr.getProperty("maxMineSpeed", "20"));
            pr.setProperty("opOnly", String.valueOf(opOnly));
            pr.setProperty("maxFlySpeed", String.valueOf(maxFly));
            pr.setProperty("maxRunSpeed", String.valueOf(maxSpeed));
            pr.setProperty("maxMineSpeed", String.valueOf(maxMine));
            try (OutputStream out = Files.newOutputStream(f)) { pr.store(out, "Util Client - opOnly=true: chi OP (hoac singleplayer) moi dung duoc"); }
        } catch (Exception e) { System.err.println("[utilclient] config loi, dung mac dinh: " + e); }
    }
}
