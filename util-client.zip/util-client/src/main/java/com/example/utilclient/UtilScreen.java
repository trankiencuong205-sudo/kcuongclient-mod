package com.example.utilclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class UtilScreen extends Screen {
    public UtilScreen() { super(Text.literal("Util Client")); }

    private String onoff(boolean b) { return b ? "BAT" : "TAT"; }

    @Override
    protected void init() {
        var s = UtilClient.st;
        int w = 220, x = width / 2 - w / 2, y = height / 2 - 70;
        addDrawableChild(ButtonWidget.builder(Text.literal("Bay (G): " + onoff(s.fly())), b -> { UtilClient.send(0, s.fly() ? 0 : 1); refresh(); }).dimensions(x, y, w, 20).build());
        y += 26;
        stepper(x, y, w, "Toc do bay", s.flySpeed(), 1, 1, s.maxFly(), 1); y += 26;
        stepper(x, y, w, "Toc do chay", s.speed(), 1, 0.5, s.maxSpeed(), 2); y += 26;
        stepper(x, y, w, "Toc do dao", s.mine(), 1, 1, s.maxMine(), 3); y += 26;
        addDrawableChild(ButtonWidget.builder(Text.literal("Dao 3x3 (V): " + onoff(s.m3())), b -> { UtilClient.send(4, s.m3() ? 0 : 1); refresh(); }).dimensions(x, y, w, 20).build());
    }

    private void stepper(int x, int y, int w, String name, double val, double min, double step, double max, int action) {
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> { UtilClient.send(action, Math.max(min, val - step)); refresh(); }).dimensions(x, y, 24, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(name + ": x" + UtilClient.fmt(val)), b -> { }).dimensions(x + 26, y, w - 52, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> { UtilClient.send(action, Math.min(max, val + step)); refresh(); }).dimensions(x + w - 24, y, 24, 20).build());
    }

    /** server gui lai trang thai sau vai tick -> ve lai menu */
    private void refresh() { client.execute(() -> { }); scheduled = 4; }
    private int scheduled = 0;

    @Override
    public void tick() { if (scheduled > 0 && --scheduled == 0) clearAndInit(); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Util Client"), width / 2, height / 2 - 95, 0xFFFFFFFF);
        if (!UtilClient.st.allowed())
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Ban khong co quyen (can OP, hoac mod chua cai tren server)."), width / 2, height / 2 + 70, 0xFFFF7070);
        else
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Bay: bam cach 2 lan. Giu Shift khi dao = chi 1 o."), width / 2, height / 2 + 70, 0xFFAAAAAA);
    }
}
